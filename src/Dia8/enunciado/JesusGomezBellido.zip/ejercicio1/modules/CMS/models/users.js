function getCurrentUser() {
    return 'Jose'
}

export default {
    getCurrentUser
}