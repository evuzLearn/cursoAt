import CMS from './CMS';
import Main from './main';
import Problems from './problems';
import ProblemDetails from './problemDetails';

export {
    CMS,
    Main,
    Problems,
    ProblemDetails
};
